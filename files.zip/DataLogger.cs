using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Text;
using UnityEngine;

namespace JndUfo
{
    /// <summary>
    /// Minimal per-shot data logger for the JND study. One row per shot: condition
    /// (side / fps / latency) and outcome (hit position, tower position, distance,
    /// score). Writes a CSV to Application.persistentDataPath. Expand freely.
    /// </summary>
    public class DataLogger : MonoBehaviour
    {
        public string participantId = "P000";
        public string sessionLabel = "session1";
        [Tooltip("Flush after every shot (safer) or only on quit (fewer writes).")]
        public bool writeOnEachShot = true;

        readonly List<string> _rows = new List<string>();
        int _trial = 0;
        string _path;

        void Awake()
        {
            string file = $"jnd_{participantId}_{sessionLabel}_{System.DateTime.Now:yyyyMMdd_HHmmss}.csv";
            _path = Path.Combine(Application.persistentDataPath, file);
            _rows.Add("trial,time,side,fps,latency_ms,hit_x,hit_z,tower_x,tower_z,distance,shot_score,total_score");
            Debug.Log($"[DataLogger] writing to {_path}");
        }

        public void LogShot(string side, int fps, float latencyMs,
                             Vector3 hit, Vector3 towerBase,
                             float distance, float shotScore, float totalScore)
        {
            _trial++;
            var ci = CultureInfo.InvariantCulture;
            _rows.Add(string.Join(",", new[]
            {
                _trial.ToString(ci),
                Time.unscaledTime.ToString("F3", ci),
                side,
                fps.ToString(ci),
                latencyMs.ToString("F1", ci),
                hit.x.ToString("F3", ci), hit.z.ToString("F3", ci),
                towerBase.x.ToString("F3", ci), towerBase.z.ToString("F3", ci),
                distance.ToString("F3", ci),
                shotScore.ToString("F2", ci),
                totalScore.ToString("F2", ci),
            }));

            if (writeOnEachShot) Flush();
        }

        public void Flush()
        {
            try { File.WriteAllText(_path, string.Join("\n", _rows), new UTF8Encoding(false)); }
            catch (System.Exception e) { Debug.LogWarning($"[DataLogger] write failed: {e.Message}"); }
        }

        void OnApplicationQuit() => Flush();
        public string OutputPath => _path;
    }
}
