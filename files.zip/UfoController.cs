using UnityEngine;

namespace JndUfo
{
    /// <summary>
    /// Moves the UFO with the mouse on a camera-relative horizontal plane, and clamps
    /// its altitude (the Y limit — "can only come down so far"). Reads the mouse through
    /// the InputLatencyBuffer so the latency manipulation applies to control.
    /// </summary>
    [RequireComponent(typeof(InputLatencyBuffer))]
    public class UfoController : MonoBehaviour
    {
        [Header("References")]
        public CameraRig rig;

        [Header("Horizontal Movement (camera-relative)")]
        [Tooltip("How far (world units) the UFO can travel from the rig centre to a screen edge.")]
        public float planeExtent = 30f;
        public float moveLerp = 12f;

        [Header("Altitude / Y limit")]
        public float cruiseHeight = 15f;
        [Tooltip("Lowest the UFO may descend (world Y).")]
        public float minY = 8f;
        [Tooltip("Highest the UFO may rise (world Y).")]
        public float maxY = 22f;
        [Tooltip("Scroll-wheel altitude speed. Set to 0 to lock the UFO at cruiseHeight.")]
        public float altitudeSpeed = 10f;

        InputLatencyBuffer _input;
        float _targetY;

        void Awake()
        {
            _input = GetComponent<InputLatencyBuffer>();
            if (rig == null) rig = CameraRig.Instance;
            _targetY = Mathf.Clamp(cruiseHeight, minY, maxY);
        }

        void Update()
        {
            Camera cam = rig != null ? rig.ActiveCamera : Camera.main;
            if (cam == null) return;

            // Latency-delayed mouse -> normalised screen coords in [-0.5, 0.5].
            Vector2 mouse = _input.GetDelayedMousePosition();
            float nx = Mathf.Clamp01(mouse.x / Screen.width) - 0.5f;
            float ny = Mathf.Clamp01(mouse.y / Screen.height) - 0.5f;

            // Altitude (scroll), clamped to the Y limit.
            if (altitudeSpeed != 0f)
                _targetY = Mathf.Clamp(_targetY + Input.mouseScrollDelta.y * altitudeSpeed * Time.deltaTime, minY, maxY);

            Vector3 right = rig != null ? rig.Right : Vector3.right;
            Vector3 fwd = rig != null ? rig.Forward : Vector3.forward;
            Vector3 anchor = rig != null ? rig.transform.position : Vector3.zero;

            Vector3 target = anchor
                             + right * (nx * 2f * planeExtent)
                             + fwd * (ny * 2f * planeExtent);
            target.y = Mathf.Clamp(_targetY, minY, maxY);

            transform.position = Vector3.Lerp(transform.position, target,
                1f - Mathf.Exp(-moveLerp * Time.deltaTime));
        }

        public float MinY => minY;
        public float MaxY => maxY;
    }
}
