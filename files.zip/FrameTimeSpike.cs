using System.Diagnostics;
using System.Threading;
using UnityEngine;

namespace JndUfo
{
    /// <summary>
    /// Induces a one-shot frame-time spike by stalling the main thread for a set number
    /// of milliseconds. Call Trigger(magnitudeMs) (e.g. when the UFO crosses the tower).
    /// The stall runs in LateUpdate so the current frame takes that much longer to render.
    /// </summary>
    public class FrameTimeSpike : MonoBehaviour
    {
        [Tooltip("Default stall (ms) if Trigger() is called with no argument.")]
        public float defaultMagnitudeMs = 100f;

        [Tooltip("Busy-wait (100% CPU, like a compute hitch) vs Thread.Sleep (yields the thread).")]
        public bool useBusyWait = true;

        bool _pending;
        float _pendingMs;

        public void Trigger() => Trigger(defaultMagnitudeMs);

        public void Trigger(float magnitudeMs)
        {
            _pending = true;
            _pendingMs = Mathf.Max(0f, magnitudeMs);
        }

        void LateUpdate()
        {
            if (!_pending) return;
            _pending = false;
            Stall(_pendingMs);
        }

        void Stall(float ms)
        {
            if (ms <= 0f) return;

            if (useBusyWait)
            {
                var sw = Stopwatch.StartNew();
                while (sw.Elapsed.TotalMilliseconds < ms) { /* spin the main thread */ }
                sw.Stop();
            }
            else
            {
                Thread.Sleep(Mathf.RoundToInt(ms));
            }
        }
    }
}
