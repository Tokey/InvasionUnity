using UnityEngine;

namespace JndUfo
{
    /// <summary>
    /// Attach to your Tower Pack prefab. Holds its ground/base position and toggles
    /// its renderers so the player only sees it when a shot reveals it.
    /// </summary>
    public class RadioTower : MonoBehaviour
    {
        [Tooltip("Renderers toggled on reveal/hide. If empty, all child renderers are used.")]
        public Renderer[] renderers;

        [Tooltip("Optional explicit base/ground point. If empty, transform.position is used.")]
        public Transform basePoint;

        bool _visible = true;

        void Awake()
        {
            if (renderers == null || renderers.Length == 0)
                renderers = GetComponentsInChildren<Renderer>(true);
            SetVisible(false);
        }

        public Vector3 BasePosition => basePoint != null ? basePoint.position : transform.position;
        public bool IsVisible => _visible;

        public void SetVisible(bool visible)
        {
            _visible = visible;
            foreach (var r in renderers)
                if (r != null) r.enabled = visible;
        }

        public void MoveTo(Vector3 worldPos) => transform.position = worldPos;
    }
}
