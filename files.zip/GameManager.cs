using UnityEngine;

namespace JndUfo
{
    /// <summary>
    /// Wires the subsystems together and orchestrates a shot:
    /// fire -> score by distance -> log -> reveal tower + marker -> hide & move tower.
    /// Drop this on an empty "GameManager" object and assign the references.
    /// </summary>
    public class GameManager : MonoBehaviour
    {
        public static GameManager Instance { get; private set; }

        [Header("Config")]
        public ExperimentConfig config;

        [Header("References")]
        public LaserFirer laser;
        public TowerManager towerManager;
        public ScoreManager scoreManager;
        public PerturbationController perturbation;
        public DataLogger logger;

        void Awake() => Instance = this;

        void Start()
        {
            // Push the shared config into the subsystems that read it.
            if (scoreManager != null) scoreManager.config = config;
            if (towerManager != null) towerManager.config = config;
            if (perturbation != null) perturbation.config = config;

            if (laser != null)
            {
                laser.SetCooldown(config != null ? config.fireCooldown : 0.25f);
                laser.OnShotFired += HandleShotFired;
            }
        }

        void OnDestroy()
        {
            if (laser != null) laser.OnShotFired -= HandleShotFired;
        }

        void HandleShotFired(Vector3 hitPoint, bool hitGround)
        {
            Vector3 towerBase = towerManager != null ? towerManager.TowerBase : Vector3.zero;

            float shotScore = 0f, total = 0f, dist = 0f;
            if (scoreManager != null)
            {
                shotScore = scoreManager.ScoreShot(hitPoint, towerBase);
                total = scoreManager.TotalScore;
                dist = scoreManager.LastShotDistance;
            }

            if (logger != null && perturbation != null)
            {
                logger.LogShot(
                    perturbation.CurrentSide.ToString(),
                    perturbation.CurrentFps,
                    perturbation.CurrentLatencyMs,
                    hitPoint, towerBase, dist, shotScore, total);
            }

            if (towerManager != null) towerManager.RevealThenMove(hitPoint);
        }
    }
}
