using UnityEngine;

namespace JndUfo
{
    /// <summary>
    /// Central anchor for "everything relative to the camera".
    /// Attach this to your main Camera (or a parent rig at the camera's position).
    /// The helper properties give camera-relative axes flattened onto the horizontal
    /// play plane, used by the UFO movement and the tower spawn bounds. As the camera
    /// moves, the whole play field re-centres under it.
    /// </summary>
    public class CameraRig : MonoBehaviour
    {
        public static CameraRig Instance { get; private set; }

        [Tooltip("Camera used for camera-relative math. Defaults to a Camera on this object, else Camera.main.")]
        public Camera cam;

        [Header("Optional Follow")]
        public bool follow = false;
        public Transform followTarget;
        public Vector3 followOffset = Vector3.zero;
        public float followLerp = 10f;

        void Awake()
        {
            Instance = this;
            if (cam == null) cam = GetComponent<Camera>();
            if (cam == null) cam = Camera.main;
        }

        void LateUpdate()
        {
            if (follow && followTarget != null)
            {
                Vector3 desired = followTarget.position + followOffset;
                transform.position = Vector3.Lerp(transform.position, desired,
                    1f - Mathf.Exp(-followLerp * Time.unscaledDeltaTime));
            }
        }

        /// <summary>Camera right, flattened to the XZ play plane.</summary>
        public Vector3 Right
        {
            get
            {
                Vector3 r = cam != null ? cam.transform.right : Vector3.right;
                r.y = 0f;
                return r.sqrMagnitude > 1e-6f ? r.normalized : Vector3.right;
            }
        }

        /// <summary>Camera forward, flattened to the XZ play plane.</summary>
        public Vector3 Forward
        {
            get
            {
                Vector3 f = cam != null ? cam.transform.forward : Vector3.forward;
                f.y = 0f;
                return f.sqrMagnitude > 1e-6f ? f.normalized : Vector3.forward;
            }
        }

        public Vector3 Up => Vector3.up;
        public Camera ActiveCamera => cam != null ? cam : Camera.main;
    }
}
