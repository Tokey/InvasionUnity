# JND UFO — skeleton setup

All scripts are in the `JndUfo` namespace, so they reference each other without `using`
statements. Drop the `Scripts` folder into `Assets/` and the three PNGs into `Assets/Textures/`.

## Suggested scene hierarchy
```
Main Camera            -> CameraRig            (angled top-down, looking at the ground)
Directional Light
Ground (plane/quad)    -> set its layer to "Ground", add a Collider
GameManager (empty)    -> GameManager, ScoreManager, PerturbationController,
                          FrameRateController, FrameTimeSpike, DataLogger
UFO (your prefab)      -> UfoController, InputLatencyBuffer, LaserFirer
   └─ FirePoint        -> empty child placed at the gun muzzle (auto-created if omitted)
Tower (your prefab)    -> RadioTower
Cloud (empty)          -> CloudCover  +  a child ParticleSystem (see below)
ExperimentConfig.asset -> Create > JND UFO > Experiment Config
```

## Wiring (Inspector)
- **GameManager**: assign `config`, `laser`, `towerManager`, `scoreManager`, `perturbation`, `logger`.
- **PerturbationController**: assign `ufo` (the UFO transform), `towerManager`,
  `frameTimeSpike`, `frameRateController`, `inputLatency` (the buffer on the UFO).
- **TowerManager**: assign `tower` (RadioTower), `cloud` (CloudCover). Set spawn bounds + `groundY`.
- **LaserFirer**: set `groundMask` to the Ground layer. (URP only) assign a `beamMaterial`.
- **UfoController**: set `minY` (descent floor / Y limit), `maxY`, `cruiseHeight`.

The GameManager pushes the config into ScoreManager / TowerManager / PerturbationController
at runtime, so you only assign the config in one place.

## Cloud particle setup (uses the supplied textures)
1. Create a Material:
   - Built-in RP: shader `Mobile/Particles/Alpha Blended` (or `Particles/Standard Unlit`, Rendering Mode = Fade).
   - URP: shader `Universal Render Pipeline/Particles/Unlit`, Surface = Transparent.
   - Albedo / Base Map = `cloud_puff_soft.png` (clean blend) or `cloud_puff.png` (more detail). Color = white.
2. Texture import settings (all three PNGs): **Alpha Is Transparency = ON**.
3. ParticleSystem (child of Cloud): Renderer material = the cloud material;
   Start Size ~5–15, low Rate over Time (or a Burst), slow/zero velocity, Random rotation,
   3D Start Size off. Position it just above `groundY` over the tower.
   `cloud_blanket.png` works on a stretched billboard quad if you prefer a flat fog band.
4. CloudCover fades the particle/renderer alpha: 1 = obscured, 0 = revealed.

Zero-asset alternative: skip particles and just use Unity's built-in distance fog
(`Window > Rendering > Lighting > Environment > Fog`); CloudCover can stay unused or you
can toggle `RenderSettings.fog` in `Reveal()/Obscure()`.

## Assumptions baked in (change as needed)
- The tower is **hidden in the cloud** until a shot reveals it; the player aims into the fog.
- The tower **divides the field into camera-left / camera-right halves**, each carrying one
  condition (FPS A/B, latency A/B). **Crossing directly over the tower triggers the FT spike.**
- Perturbations are **active even while the tower is hidden** (driven by its true position),
  so the player can feel the change as they cross the invisible boundary.
- A shot is a "trial": score by proximity, then the tower moves. There is **no health/destruction
  model** yet — points reward getting closer.

## Caveats
- Uses the **legacy Input Manager** (`Input.mousePosition`, `Input.GetMouseButtonDown`).
  If your project is on the new Input System only, swap those calls.
- `Application.targetFrameRate = 500` is a **cap, not a guarantee**, and the Editor adds
  overhead — verify high FPS in a **standalone build**.
- The FT spike is implemented from scratch (busy-wait stall). Put your Lead Rush magnitude
  in `spikeMagnitudeMs`, or paste that code into `FrameTimeSpike.Stall()` to match it exactly.
- Materials created at runtime (`r.material`) are per-instance; fine for a skeleton.
