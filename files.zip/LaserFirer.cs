using System;
using System.Collections;
using UnityEngine;

namespace JndUfo
{
    /// <summary>
    /// Fires a laser straight down from a fire point below the UFO gun. The beam is
    /// drawn entirely in code with a LineRenderer, and a raycast finds the ground hit
    /// point. Raises OnShotFired(hitPoint, didHitGround) for the GameManager.
    /// </summary>
    public class LaserFirer : MonoBehaviour
    {
        [Header("Fire Point (directly below the UFO gun)")]
        [Tooltip("Assign a child transform at the gun muzzle. If left empty, one is created at autoFirePointOffset.")]
        public Transform firePoint;
        public Vector3 autoFirePointOffset = new Vector3(0f, -1.0f, 0f);

        [Header("Beam")]
        [Tooltip("Which layers count as 'ground'.")]
        public LayerMask groundMask = ~0;
        public float maxRange = 200f;
        [Tooltip("Fire direction in world space. Down by default.")]
        public Vector3 fireDirection = Vector3.down;
        public float beamWidth = 0.15f;
        public Color beamColor = new Color(0.2f, 1f, 0.4f, 1f);
        public float beamDuration = 0.12f;
        [Tooltip("Optional. If empty, an unlit material is built at runtime (URP users: assign one).")]
        public Material beamMaterial;

        [Header("Input")]
        public bool fireOnLeftClick = true;
        public KeyCode altFireKey = KeyCode.Space;

        /// <summary>(hitPoint, didHitGround)</summary>
        public event Action<Vector3, bool> OnShotFired;

        LineRenderer _line;
        float _lastFireTime = -999f;
        float _cooldown = 0.25f;

        public void SetCooldown(float c) => _cooldown = c;

        void Awake()
        {
            if (firePoint == null)
            {
                var fp = new GameObject("FirePoint").transform;
                fp.SetParent(transform, false);
                fp.localPosition = autoFirePointOffset;
                firePoint = fp;
            }

            _line = GetComponent<LineRenderer>();
            if (_line == null) _line = gameObject.AddComponent<LineRenderer>();
            _line.enabled = false;
            _line.positionCount = 2;
            _line.useWorldSpace = true;
            _line.numCapVertices = 4;
            _line.widthMultiplier = beamWidth;
            _line.material = beamMaterial != null ? beamMaterial : BuildBeamMaterial();
            _line.startColor = _line.endColor = beamColor;
        }

        static Material BuildBeamMaterial()
        {
            Shader sh = Shader.Find("Sprites/Default");
            if (sh == null) sh = Shader.Find("Unlit/Color");
            if (sh == null) sh = Shader.Find("Legacy Shaders/Particles/Alpha Blended");
            if (sh == null) sh = Shader.Find("Standard");
            return new Material(sh);
        }

        void Update()
        {
            bool wantsFire = (fireOnLeftClick && Input.GetMouseButtonDown(0)) || Input.GetKeyDown(altFireKey);
            if (wantsFire && Time.time - _lastFireTime >= _cooldown)
                Fire();
        }

        public void Fire()
        {
            _lastFireTime = Time.time;

            Vector3 origin = firePoint.position;
            Vector3 dir = fireDirection.sqrMagnitude > 1e-6f ? fireDirection.normalized : Vector3.down;

            Vector3 endPoint = origin + dir * maxRange;
            bool hit = false;
            if (Physics.Raycast(origin, dir, out RaycastHit info, maxRange, groundMask, QueryTriggerInteraction.Ignore))
            {
                endPoint = info.point;
                hit = true;
            }

            StartCoroutine(FlashBeam(origin, endPoint));
            OnShotFired?.Invoke(endPoint, hit);
        }

        IEnumerator FlashBeam(Vector3 a, Vector3 b)
        {
            _line.widthMultiplier = beamWidth;
            _line.startColor = _line.endColor = beamColor;
            _line.SetPosition(0, a);
            _line.SetPosition(1, b);
            _line.enabled = true;

            float t = 0f;
            while (t < beamDuration)
            {
                t += Time.deltaTime;
                _line.widthMultiplier = beamWidth * (1f - t / beamDuration);
                yield return null;
            }
            _line.enabled = false;
        }
    }
}
