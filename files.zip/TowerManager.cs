using System.Collections;
using UnityEngine;

namespace JndUfo
{
    /// <summary>
    /// Places and moves the tower (each shot), reveals it with a hit marker after a
    /// shot, then re-hides it under the cloud and relocates it. Spawn bounds are
    /// camera-relative so the play area follows the camera.
    /// </summary>
    public class TowerManager : MonoBehaviour
    {
        [Header("References")]
        public CameraRig rig;
        public RadioTower tower;
        public CloudCover cloud;
        [HideInInspector] public ExperimentConfig config; // set by GameManager

        [Header("Spawn Bounds (camera-relative, on the ground plane)")]
        [Tooltip("Half-extent along the camera RIGHT axis.")]
        public float halfWidth = 20f;
        [Tooltip("Half-extent along the camera FORWARD axis.")]
        public float halfDepth = 20f;
        [Tooltip("World Y of the ground the tower sits on.")]
        public float groundY = 0f;

        [Header("Hit Marker")]
        [Tooltip("Optional. If empty, a small flat cylinder is created at runtime.")]
        public GameObject hitMarkerPrefab;
        Transform _hitMarker;

        public RadioTower Tower => tower;
        public Vector3 TowerBase => tower != null ? tower.BasePosition : transform.position;

        void Start()
        {
            if (rig == null) rig = CameraRig.Instance;
            EnsureHitMarker();
            MoveTowerToRandomPosition();
            HideTower();
        }

        public void RevealThenMove(Vector3 hitPoint)
        {
            StopAllCoroutines();
            StartCoroutine(RevealRoutine(hitPoint));
        }

        IEnumerator RevealRoutine(Vector3 hitPoint)
        {
            ShowTower();
            ShowHitMarker(hitPoint);
            float dur = config != null ? config.revealDuration : 1.5f;
            yield return new WaitForSecondsRealtime(dur);
            HideTower();
            HideHitMarker();
            MoveTowerToRandomPosition();
        }

        public void MoveTowerToRandomPosition()
        {
            Vector3 anchor = rig != null ? rig.transform.position : Vector3.zero;
            Vector3 right = rig != null ? rig.Right : Vector3.right;
            Vector3 fwd = rig != null ? rig.Forward : Vector3.forward;

            float u = Random.Range(-halfWidth, halfWidth);
            float v = Random.Range(-halfDepth, halfDepth);

            Vector3 pos = anchor + right * u + fwd * v;
            pos.y = groundY;

            if (tower != null) tower.MoveTo(pos);
            if (cloud != null) cloud.MoveOver(pos);
        }

        void ShowTower()
        {
            if (tower != null) tower.SetVisible(true);
            if (cloud != null) cloud.Reveal();
        }

        void HideTower()
        {
            if (tower != null) tower.SetVisible(false);
            if (cloud != null) cloud.Obscure();
        }

        void EnsureHitMarker()
        {
            if (hitMarkerPrefab != null)
            {
                _hitMarker = Instantiate(hitMarkerPrefab).transform;
            }
            else
            {
                var go = GameObject.CreatePrimitive(PrimitiveType.Cylinder);
                go.name = "HitMarker";
                Destroy(go.GetComponent<Collider>());
                go.transform.localScale = new Vector3(0.6f, 0.05f, 0.6f);
                var rend = go.GetComponent<Renderer>();
                if (rend != null) rend.material.color = new Color(1f, 0.3f, 0.1f, 1f);
                _hitMarker = go.transform;
            }
            _hitMarker.gameObject.SetActive(false);
        }

        void ShowHitMarker(Vector3 p)
        {
            if (_hitMarker == null) return;
            _hitMarker.position = new Vector3(p.x, groundY + 0.03f, p.z);
            _hitMarker.gameObject.SetActive(true);
        }

        void HideHitMarker()
        {
            if (_hitMarker != null) _hitMarker.gameObject.SetActive(false);
        }
    }
}
