using System;
using UnityEngine;

namespace JndUfo
{
    /// <summary>
    /// Scores each shot by horizontal distance from the tower base: full points within
    /// hitRadius, linear falloff to zero at maxScoringDistance, then a growing penalty
    /// beyond that. All thresholds live in ExperimentConfig.
    /// </summary>
    public class ScoreManager : MonoBehaviour
    {
        [HideInInspector] public ExperimentConfig config; // set by GameManager

        public float TotalScore { get; private set; }
        public float LastShotScore { get; private set; }
        public float LastShotDistance { get; private set; }

        /// <summary>(lastShotScore, totalScore, distance)</summary>
        public event Action<float, float, float> OnScored;

        public float ScoreShot(Vector3 hitPoint, Vector3 towerBase)
        {
            Vector3 a = new Vector3(hitPoint.x, 0f, hitPoint.z);
            Vector3 b = new Vector3(towerBase.x, 0f, towerBase.z);
            float dist = Vector3.Distance(a, b);
            LastShotDistance = dist;

            float maxPts = config != null ? config.maxPoints : 100f;
            float hitR = config != null ? config.hitRadius : 1f;
            float maxDist = config != null ? config.maxScoringDistance : 20f;
            float maxPen = config != null ? config.maxPenalty : 50f;

            float pts;
            if (dist <= hitR)
            {
                pts = maxPts;
            }
            else if (dist <= maxDist)
            {
                float t = Mathf.InverseLerp(hitR, maxDist, dist);
                pts = Mathf.Lerp(maxPts, 0f, t);
            }
            else
            {
                float over = Mathf.Min(dist - maxDist, maxDist);
                pts = -Mathf.Lerp(0f, maxPen, over / maxDist);
            }

            LastShotScore = pts;
            TotalScore += pts;
            OnScored?.Invoke(LastShotScore, TotalScore, dist);
            return pts;
        }

        public void ResetScore()
        {
            TotalScore = 0f;
            LastShotScore = 0f;
            LastShotDistance = 0f;
        }
    }
}
