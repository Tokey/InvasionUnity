using UnityEngine;

namespace JndUfo
{
    /// <summary>
    /// Sets the target frame rate (and disables vSync so it can take effect, including
    /// high rates like 500). PerturbationController calls SetTargetFps() per side.
    /// NOTE: targetFrameRate is a CAP, not a guarantee — the scene must be able to render
    /// that fast, and the Editor adds overhead, so verify high FPS in a standalone build.
    /// </summary>
    public class FrameRateController : MonoBehaviour
    {
        int _current = -1;

        void Awake() => QualitySettings.vSyncCount = 0;

        public void SetTargetFps(int fps)
        {
            if (fps == _current) return;
            _current = fps;
            QualitySettings.vSyncCount = 0;
            Application.targetFrameRate = fps;
        }

        public int CurrentTargetFps => _current;
    }
}
