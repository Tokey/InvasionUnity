using UnityEngine;

namespace JndUfo
{
    /// <summary>
    /// Core JND logic. Works out which side of the tower the UFO is on (camera-relative
    /// left/right), applies the per-side FPS and input-latency conditions every frame,
    /// and fires a one-shot frame-time spike when the UFO crosses directly over the tower.
    /// These run continuously off the tower's true position — even while it's hidden in
    /// the cloud — so the player can perceive the difference as they cross the (invisible)
    /// boundary. Exposes the current condition for the data logger.
    /// </summary>
    public class PerturbationController : MonoBehaviour
    {
        [Header("References")]
        [HideInInspector] public ExperimentConfig config; // set by GameManager
        public CameraRig rig;
        public Transform ufo;
        public TowerManager towerManager;

        [Header("Effectors")]
        public FrameTimeSpike frameTimeSpike;
        public FrameRateController frameRateController;
        public InputLatencyBuffer inputLatency;

        // Read by the logger.
        public ExperimentConfig.Side CurrentSide { get; private set; } = ExperimentConfig.Side.Left;
        public float CurrentLatencyMs { get; private set; }
        public int CurrentFps { get; private set; }

        int _lastSideSign = 0; // -1 left, +1 right, 0 = inside dead-zone / unset

        void Start()
        {
            if (rig == null) rig = CameraRig.Instance;
            if (frameRateController != null)
                frameRateController.SetTargetFps(config != null ? config.defaultFps : 60);
        }

        void Update()
        {
            if (config == null || ufo == null || towerManager == null) return;

            Vector3 right = rig != null ? rig.Right : Vector3.right;
            float along = Vector3.Dot(ufo.position - towerManager.TowerBase, right);

            // --- Crossing detection (one-shot frame-time spike) ---
            float dz = Mathf.Max(0f, config.crossingDeadZone);
            int sideSign = _lastSideSign;
            if (along > dz) sideSign = +1;
            else if (along < -dz) sideSign = -1;
            // inside +/- dz: keep previous sign (this band is "directly above the tower")

            if (sideSign != 0 && _lastSideSign != 0 && sideSign != _lastSideSign)
            {
                if (config.enableFrameTimeSpike && frameTimeSpike != null)
                {
                    frameTimeSpike.useBusyWait = config.spikeUseBusyWait;
                    frameTimeSpike.Trigger(config.spikeMagnitudeMs);
                }
            }
            if (sideSign != 0) _lastSideSign = sideSign;

            // --- Continuous per-side conditions ---
            CurrentSide = (_lastSideSign >= 0) ? ExperimentConfig.Side.Right : ExperimentConfig.Side.Left;

            int fps = config.defaultFps;
            if (config.enableFpsSwitch)
                fps = (CurrentSide == ExperimentConfig.Side.Left) ? config.fpsLeft : config.fpsRight;
            if (frameRateController != null) frameRateController.SetTargetFps(fps);
            CurrentFps = fps;

            float latMs = config.defaultLatencyMs;
            if (config.enableLatencySwitch)
                latMs = (CurrentSide == ExperimentConfig.Side.Left) ? config.latencyLeftMs : config.latencyRightMs;
            if (inputLatency != null) inputLatency.CurrentLatencySeconds = latMs / 1000f;
            CurrentLatencyMs = latMs;
        }
    }
}
